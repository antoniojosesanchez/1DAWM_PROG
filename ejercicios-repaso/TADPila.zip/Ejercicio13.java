import clases.TADPila;

/**
 * @author Antonio J.Sánchez 
 * @author José David Quero
 */
public class Ejercicio13 {
 
    
    public static void main(String[] args) {
        
        TADPila p1  ;
        TADPila p2 ;

        

        p1 = new TADPila<Integer>(100) ;
        

       

            if (!p1.esVacia()) System.out.println(p1.cima()) ;

            if (!p1.esLlena()) p1.meter(5) ;
            if (!p1.esLlena()) p1.meter(23) ;
            if (!p1.esLlena()) p1.meter(8) ;
    
            System.out.println(p1.sacar());
    
            if (!p1.esLlena()) p1.meter(-1) ;

       

    }

}
