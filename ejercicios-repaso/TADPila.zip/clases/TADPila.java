/**
 * @author Antonio J.Sánchez 
 * @author José David Quero
 */
package clases;

import java.util.ArrayList;

public class TADPila<T> {
    
    //private final int SIZE = 100 ;

    private int tope ;
    private int ultimo ;
    private ArrayList<T> pila ;

    public TADPila(int tope) {

        // inicializamos la pila (el array)
        this.tope = tope ;
        this.pila = new ArrayList<T>() ;
        //this.ultimo = 0 ;
    }

    /**  
     * Introduce un elemento en la pila  
     * @param item
     */
    public void meter(T item) {
        //this.pila[this.ultimo] = numero ;
        //this.ultimo++ ;
        this.pila.add(item) ;
    } 

    /**
     * Saca el último elemento introducido y lo devuelve     
     * @return
     */
    public T sacar() {
        //this.ultimo-- ;
        //return this.pila[this.ultimo] ;
        return this.pila.removeLast() ;
    }

    /**
     * Comprueba si la pila es o no vacía
     * @return
     */
    public boolean esVacia() {
       // return this.ultimo == 0 ; // CON ARRAYS
       return this.pila.isEmpty() ; // CON ARRAYLIST
    }

    /**
     * Comprueba si la pila está llena por completo
     * @return
     */
    public boolean esLlena() {
        //return this.ultimo == SIZE ;          // CON ARRAYS
        return this.pila.size() == this.tope ;  // CON ARRAYLIST
    }

    /**
     * Devuelve el elemento de la cima de la pila
     * @return
     */
    public T cima()  {

        /*try {
            return this.pila[this.ultimo-1] ;
        } catch(ArrayIndexOutOfBoundsException aioobe) {
            throw new ArrayIndexOutOfBoundsException() ;
        }*/
        return this.pila.getLast() ;
    }


}
